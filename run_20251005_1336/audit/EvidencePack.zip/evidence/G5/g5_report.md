# G5 OOS Audit Report

## OOS vs IS
Sharpe_IS: 0
Sharpe_OOS: NA
CAGR_OOS: NA
MaxDD_OOS: NA
Trades_OOS: NA
WinRate_OOS: NA
Turnover_OOS: NA
IS→OOS Sharpe ratio: 0

## Buy&Hold Sanity
Sharpe_BH: NA
Edge_vs_BH (Sharpe_OOS - Sharpe_BH): 0
BH equity: bh_equity.csv

## Walk-Forward (Rolling)
WFO table: wfo_table.csv
WFO summary: wfo_summary.json

## Thresholds & Decision
G5 = REJECT
Reasons:
- MISSING_DATA: OOS price series insufficient
