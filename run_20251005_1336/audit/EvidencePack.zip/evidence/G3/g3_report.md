# G3 Costs & Risk-Limits Report

## Costs
Commissions total: 0,01, Slippage total: 0,005, Borrow total: 0, Funding total: 0
Sharpe (IS) before costs: 
0,375346
Sharpe (IS) after costs: 
0,516326
See costs breakdown: 
costs_breakdown.csv

## Risk Checks
Gross exposure mean/max: 0,5/1
Net exposure min/max: 0/1
Leverage max: 1
Turnover mean/max: 1/1

## Thresholds & Decision
Missing/TODO thresholds: 
none
G3 = PASS

## Reasons
- NEEDS_DATA/FEATURES: synthetic examples used
