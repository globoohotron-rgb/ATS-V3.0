# G2 Report

## Grid
Size: 4 (limit <= 8)

## Candidates
| model_id | type | params | objective | is_sharpe | cagr | maxdd | trades | winrate | turnover |
|----------|------|--------|-----------|-----------|------|-------|--------|---------|----------|
| model_id: m_momentum | unknown | {} | Sharpe | 0 | 0 | 0 | 0 | 0 | 0 |
| model_id: m_momentum | unknown | {} | Sharpe | 0 | 0 | 0 | 0 | 0 | 0 |
| model_id: m_meanrev | unknown | {} | Sharpe | 0 | 0 | 0 | 0 | 0 | 0 |
| model_id: m_baseline | unknown | {} | Sharpe | 0 | 0 | 0 | 0 | 0 | 0 |

## Selection
| model_id | type | params | objective | is_sharpe | cagr | maxdd | trades | winrate | turnover |
|----------|------|--------|-----------|-----------|------|-------|--------|---------|----------|
| model_id: m_momentum | unknown | {} | Sharpe | 0 | 0 | 0 | 0 | 0 | 0 |

## Thresholds & Decision
Missing/TO-DO thresholds: 
is_sharpe_min, max_turnover, min_trades
G2 = NEEDS_THRESHOLD

## Reasons
- OK
