# G4 Audit Findings

Status: NEEDS_THRESHOLD
Reasons:
- NEEDS_THRESHOLD:fill_rate_min,max_slippage_bps_p95,max_rejects_pct,latency_ms_p95

Metrics snapshot:
- orders: 0
- fill_rate.mean: 0
- latency_ms.p95: 0
- slippage_bps.p95: 0

Evidence:
- orders.csv
- fills.csv
- g4_metrics.json
- g4_report.md
